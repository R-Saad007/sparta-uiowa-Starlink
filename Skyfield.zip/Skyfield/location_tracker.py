import skyfield
from skyfield.api import load, wgs84
from skyfield.api import EarthSatellite
from math import cos, asin, sqrt, pi

# # For Version Check
# if skyfield.VERSION < (1, 24):
#     print("Old Version")

# Making use of Haversine Formula to get the distance between 2 points using their longitude and latitude values
def distance(lat1, lon1, lat2, lon2):
    p = pi/180
    a = 0.5 - cos((lat2-lat1)*p)/2 + cos(lat1*p) * \
        cos(lat2*p) * (1-cos((lon2-lon1)*p))/2
    return 12742 * asin(sqrt(a))  # 2*R*asin...

# Reading TLE data from file
sat_file = 'Satellite_Data/sat44238.txt'
satellites = load.tle(sat_file)
print('Loaded', len(satellites), 'satellite/s')
# 2 line data required to instantiate a satellite object
line1 = '1 44238U 19029D   21206.29257128  .00005803  00000-0  31117-3 0  9991'
line2 = '2 44238  52.9945 175.5940 0001247  62.9689 297.1431 15.16345693118428'
sat_data = EarthSatellite(line1, line2)

# Setting timescale element
ts = load.timescale()
t_data = ts.utc(2021,month=7,day=25,hour=10,minute=0,second=0)
geocentric_position = sat_data.at(t_data)
subpoint = wgs84.subpoint(geocentric_position)
print('Latitude:', subpoint.latitude)
print('Longitude:', subpoint.longitude)
print('Height: {:.1f} km'.format(subpoint.elevation.km))
print("Epoch: ",sat_data.epoch.utc_jpl())

# constant values for antenna and (decimal converted) satellite
print("Distance from antenna:",distance(40.43742, -86.90778 , -32.57877777777778, 53.07233333333334),"km")