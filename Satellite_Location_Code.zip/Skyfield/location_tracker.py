from re import sub
import skyfield
import os
from skyfield.api import load, wgs84
from skyfield.api import EarthSatellite
from math import cos, asin, sqrt, pi


# # For Version Check
# if skyfield.VERSION < (1, 24):
#     print("Old Version")


# Setting path to read all TLE data files
path = r"C:\Users\HP\Documents\Neo\Research\Starlink-UIOWA\Skyfield\Satellite_Data"
os.chdir(path)


# Function to return the necessary first 2 lines for each TLE data file to create satellite object
def tle_data(file_name):
    with open(file_name, 'r') as f:
        f_line = f.readline()
        s_line = f.readline()
    return f_line, s_line


# Making use of Haversine Formula to get the distance between 2 points using their longitude and latitude values
def Haversine_distance(lat1, lon1, lat2, lon2):
    p = pi/180
    a = 0.5 - cos((lat2-lat1)*p)/2 + cos(lat1*p) * \
        cos(lat2*p) * (1-cos((lon2-lon1)*p))/2
    return 12742 * asin(sqrt(a))  # 2*R*asin...


# Function to convert longitude and latitude values to decimal form
def parser(data):
    parts = data.split()
    parts[0] = float(parts[0][:-3])
    parts[1] = (float(parts[1][:-1]))/60.0
    parts[2] = (float(parts[2][:-1]))/(60.0*60.0)
    if parts[0] < 0.0:
        parts[0] *= -1
        result = parts[0] + parts[1] + parts[2]
        result *= -1
        return result
    elif parts[0] >= 0.0:
        result = parts[0] + parts[1] + parts[2]
        return result


# Setting timescale element
# Here we can set the timescale value of our choice. I have currently set it to the 25th of July, 2021 (10:00:00).
ts = load.timescale()
t_data = ts.utc(2021, month=7, day=25, hour=10, minute=0, second=0)


# Code below only loads the data for one satellite and stores it in a dictionary
'''
sat_file = 'Satellite_Data/sat44238.txt'
satellites = load.tle(sat_file)
print('Loaded', len(satellites), 'satellite/s')
'''


# List to store all satellites's data (satellite name, latitude, longitude, Height, Epoch)
satellite_data_list = []
# List to store the names of certain satellites after the distance calculations have been performed using the Haversine formula
satellite_name_list = []
# List to store the particular distance values of each satellite from the antenna
distance_list = []
# Retrieving data for all satellites
# Input for the distance from the antenna for which satellites are to be found
x = float(input("Enter the distance from the antenna for which satellites are to be found: "))
for file in os.listdir():
    if file.endswith(".txt"):
        satellite_name = str(os.path.splitext(os.path.basename(file))[0])
        file_path = f"{path}\{file}"
        line1, line2 = tle_data(file_path)      
        # 2 line TLE data required to instantiate a satellite object
        sat_data = EarthSatellite(line1, line2)
        geocentric_position = sat_data.at(t_data)
        # subpoint converts the geocentric positioning to the latitude and longitude system
        subpoint = wgs84.subpoint(geocentric_position)
        # adding the satellite data to the list
        satellite_data_list.append((satellite_name,str(subpoint.latitude), str(subpoint.longitude), subpoint.elevation.km, sat_data.epoch.utc_jpl()))
        # Latitude and Longitude values of the satellite
        latitude_val = str(subpoint.latitude)
        longitude_val = str(subpoint.longitude)
        # The converted decimal values for the latitude and longitude of the satellite
        decimal_latitude_val = parser(latitude_val)
        decimal_longitude_val = parser(longitude_val)
        # Distance of the satellite from the antenna using Haversine formula
        distance_data = Haversine_distance(40.43742, -86.90778, decimal_latitude_val, decimal_longitude_val)
        # Checking whether a satellite is within a distance x from the antenna where x is the variable to be changed
        if distance_data <= x:
            satellite_name_list.append(satellite_name)
            distance_list.append(distance_data)
    else:
        print("File does not exist!")

print(f"Number of satellites at a distance of {x}km from the antenna:", len(satellite_name_list))
for x in range(len(satellite_name_list)):
    print("Satellite:",satellite_name_list[x])
    print("Distance from antenna:",distance_list[x],"km")


# Look for disconnections using packet loss data file (In Progress)
# Hypothesize an existing theory (?) Check for patterns (In Progress)


# Assumptions:
# 1) Not taking into account the newly launched satellites (September onwards)
# 2) Assuming the satellites follow a similar trajectory